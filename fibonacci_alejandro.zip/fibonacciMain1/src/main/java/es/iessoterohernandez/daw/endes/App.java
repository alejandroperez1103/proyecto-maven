package es.iessoterohernandez.daw.endes;

import es.iessoterohernandez.daw.endes.Fibonacci;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
    	Fibonacci f = new Fibonacci();
        
    	f.fibonacci();
    }
}
