package es.iessoterohernandez.daw.endes;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

public class CrearPDF {

	    public static void main(String[] args) {
	        String destino = "ejemplo.pdf";
	        
	        try {
	            PdfWriter writer = new PdfWriter(destino);
	            
	            PdfDocument pdf = new PdfDocument(writer);

	            Document documento = new Document(pdf);
	            
	            documento.add(new Paragraph("¡Hola, este es un PDF generado con iText!"));
	            
	            documento.close();
	            
	            System.out.println("PDF generado exitosamente en " + destino);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
