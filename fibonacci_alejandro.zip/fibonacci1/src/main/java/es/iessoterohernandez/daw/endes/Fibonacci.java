package es.iessoterohernandez.daw.endes;

import java.util.Scanner;

public class Fibonacci {
	public void fibonacci () {
		Scanner sc = new Scanner(System.in);
		int a = 0;
		int b = 1;
		
		System.out.println("Dime cuántas veces quieres hacer la suma");
		int num = sc.nextInt();
		
		for(int i=0; i<(num/2); i++) {
			System.out.println(a);
			a = a+b;
			System.out.println(b);
			b = a+b;
				
		}
	}
}	

